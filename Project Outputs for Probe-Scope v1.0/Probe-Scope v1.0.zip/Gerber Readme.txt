NP = not present in design

GBL - Bottom Layer
GTL - Top Layer
GBS - Bottom Solder Mask
GTS - Top Solder Mask
G1 - Internal Signal Layer (Positive, Layer 2)
G2 - Internal Signal Layer (Positive, Layer 3)
G3 - Internal Signal Layer (Positive, Layer 4)
G4 - Internal Signal Layer (Positive, Layer 5)
GTO - Top Overlay (silkscreen)
GTP - Top Paste
GBP - Bottom Paste
GBO - Bottom Overlay (silkscreen)
NP DRL - NC Drill (Binary)
TXT - NC Drill (ASCII) Through Hole (via-in-pad)
TX1 - NC Drill (ASCII) Blind Microvia from Top to Layer 2 (G1)
TX2 - NC Drill (ASCII) Blind Microvia from Top to Layer 3 (G2)
NP GD1 - Drill Drawing
GM1 - Mechanical Layer board outline
NP GM2 - Mechanical Layer bottom stiffener outline
NP GM3 - Mechanical Layer bottom adhesive
GM4 - CAM instructions and Board Dimensions
GM16 - Mechanical Layer (Sheet outline and text)

xlsx - Full BOM
csv - Pick Place

Please review ALL notes on GM4 layer!!!